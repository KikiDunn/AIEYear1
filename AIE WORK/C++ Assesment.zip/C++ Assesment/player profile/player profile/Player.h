#pragma once
using namespace std;
class Player
{
  public:
	  Player();
	  Player(char name[], int ID);
	  int ID = 0;
	  char name[30];
};

